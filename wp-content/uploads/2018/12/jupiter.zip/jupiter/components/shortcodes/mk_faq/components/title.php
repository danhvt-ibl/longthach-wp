<div class="mk-toggle-title">
	<i><?php Mk_SVG_Icons::get_svg_icon_by_class_name(true, 'mk-icon-question', 16); ?></i>
	<span><?php the_title(); ?></span>
	<?php Mk_SVG_Icons::get_svg_icon_by_class_name(true, 'mk-icon-chevron-right', 13); ?>
	<div class="clearboth"></div>
</div>