<?php if(!empty($view_params['item_title'])) { ?>
	<div class="item-title">
	  <h5><?php echo $view_params['item_title']; ?></h5>
	</div>
<?php }